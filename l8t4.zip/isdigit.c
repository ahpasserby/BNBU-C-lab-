/*
=============================================
 Name: isdigit.c
 Author: Sarzn
 Version: 1.0
 Copyright: none
 Description: Implementation of isDigitChar function
 =============================================
*/
#include "digit.h"

/* Function definition
   Checks whether the given character is a decimal digit.
   Returns 1 if c is '0'..'9', returns 0 otherwise. */
_Bool isDigitChar(char c)
{
    return (c >= '0' && c <= '9');
}
