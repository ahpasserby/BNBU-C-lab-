/*
=============================================
 Name: digit.h
 Author: Sarzn
 Version: 1.0
 Copyright: none
 Description: Header file for isDigitChar function
 =============================================
*/
#ifndef DIGIT_H
#define DIGIT_H

/* Function prototype
   Returns 1 (_Bool true) if the parameter is a digit character ('0'..'9'),
   returns 0 (_Bool false) otherwise */
_Bool isDigitChar(char c);

#endif
