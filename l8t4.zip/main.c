/*
=============================================
 Name: main.c
 Author: Sarzn
 Version: 1.0
 Copyright: none
 Description: Main function for digit checking program
 =============================================
*/
#include <stdio.h>
#include "digit.h"

int main(void)
{
    char ch;
    
    printf("Enter a character: ");
    scanf("%c", &ch);                     // Read exactly one character
    
    // Call the sub-function and print its return value (1 or 0)
    printf("%d\n", isDigitChar(ch));
    
    return 0;
}
