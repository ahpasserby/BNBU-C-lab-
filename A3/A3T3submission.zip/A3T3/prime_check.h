#ifndef PRIME_CHECK_H
#define PRIME_CHECK_H

int isPrime(int n);

#endif
